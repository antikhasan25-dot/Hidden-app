package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_apps")
data class VaultAppEntity(
    @PrimaryKey val appId: String, // Package name or plugin ID
    val appName: String,
    val packageName: String,
    val versionName: String,
    val isIsolated: Boolean = true,
    val isDynamicPlugin: Boolean = false,
    val isSystemApp: Boolean = false,
    val isLocked: Boolean = false,
    val storageSizeBytes: Long = 0L,
    val lastLaunchedTimestamp: Long = System.currentTimeMillis(),
    val category: String = "Enterprise",
    val description: String = ""
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val appId: String,
    val appName: String,
    val actionType: String, // LAUNCH, ISOLATED_IO, DEX_LOADED, STORAGE_CLEARED, PERMISSION_GRANTED
    val details: String,
    val status: String = "SUCCESS" // SUCCESS, WARNING, DENIED
)
