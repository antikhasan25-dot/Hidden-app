package com.example.data

import com.example.isolation.StorageIsolationManager
import com.example.isolation.VaultStorageInfo
import com.example.launcher.AppLauncherManager
import com.example.launcher.InstalledAppInfo
import com.example.loader.DexLoadResult
import com.example.loader.DynamicDexLoader
import kotlinx.coroutines.flow.Flow
import java.io.File

class VaultRepository(
    private val vaultDao: VaultDao,
    private val storageIsolationManager: StorageIsolationManager,
    private val dynamicDexLoader: DynamicDexLoader,
    private val appLauncherManager: AppLauncherManager
) {

    val allVaultApps: Flow<List<VaultAppEntity>> = vaultDao.getAllVaultApps()
    val auditLogs: Flow<List<AuditLogEntity>> = vaultDao.getAuditLogs()

    suspend fun addAppToVault(app: VaultAppEntity) {
        vaultDao.insertOrUpdateApp(app)
        // Initialize private sandbox storage
        val storageInfo = storageIsolationManager.createIsolatedStorage(app.appId)
        vaultDao.updateStorageSize(app.appId, storageInfo.totalSizeBytes)

        logAudit(
            appId = app.appId,
            appName = app.appName,
            actionType = "ISOLATION_CREATED",
            details = "Initialized private sandbox at ${storageInfo.rootPath}",
            status = "SUCCESS"
        )
    }

    suspend fun removeAppFromVault(appId: String, appName: String) {
        vaultDao.deleteAppById(appId)
        storageIsolationManager.clearIsolatedData(appId)
        logAudit(
            appId = appId,
            appName = appName,
            actionType = "APP_REMOVED",
            details = "Cleared isolated sandbox and removed app from vault",
            status = "SUCCESS"
        )
    }

    suspend fun launchVaultApp(app: VaultAppEntity): Boolean {
        val success = if (app.isDynamicPlugin) {
            true // Dynamic plugin execution is handled in Dex loader screen
        } else {
            appLauncherManager.launchAppPackage(app.packageName)
        }

        if (success) {
            vaultDao.updateLastLaunched(app.appId, System.currentTimeMillis())
            // Refresh storage size
            val storageInfo = storageIsolationManager.getStorageInfo(app.appId)
            vaultDao.updateStorageSize(app.appId, storageInfo.totalSizeBytes)

            logAudit(
                appId = app.appId,
                appName = app.appName,
                actionType = "LAUNCH",
                details = "Launched app inside vault container context (Pkg: ${app.packageName})",
                status = "SUCCESS"
            )
        } else {
            logAudit(
                appId = app.appId,
                appName = app.appName,
                actionType = "LAUNCH",
                details = "Failed to launch target app package ${app.packageName}",
                status = "DENIED"
            )
        }
        return success
    }

    suspend fun toggleLockStatus(appId: String, appName: String, currentLockState: Boolean) {
        val newLockState = !currentLockState
        vaultDao.updateLockStatus(appId, newLockState)
        logAudit(
            appId = appId,
            appName = appName,
            actionType = if (newLockState) "LOCKED" else "UNLOCKED",
            details = "Updated vault app lock status to $newLockState",
            status = "SUCCESS"
        )
    }

    fun getStorageInfo(appId: String): VaultStorageInfo {
        return storageIsolationManager.getStorageInfo(appId)
    }

    suspend fun clearSandboxStorage(appId: String, appName: String): VaultStorageInfo {
        storageIsolationManager.clearIsolatedData(appId)
        val info = storageIsolationManager.getStorageInfo(appId)
        vaultDao.updateStorageSize(appId, info.totalSizeBytes)
        logAudit(
            appId = appId,
            appName = appName,
            actionType = "STORAGE_CLEARED",
            details = "Wiped isolated sandbox data directory",
            status = "SUCCESS"
        )
        return info
    }

    fun writeSandboxTestFile(appId: String, fileName: String, content: String): File {
        return storageIsolationManager.writeTestFileInSandbox(appId, fileName, content)
    }

    fun readSandboxFiles(appId: String): List<Pair<String, String>> {
        return storageIsolationManager.readFilesFromSandbox(appId)
    }

    // Dynamic DEX operations
    suspend fun loadDynamicDexModule(
        dexFile: File,
        className: String,
        methodName: String,
        param: String
    ): DexLoadResult {
        val result = dynamicDexLoader.loadAndExecuteClass(
            dexFile = dexFile,
            className = className,
            methodName = methodName,
            methodParam = param
        )

        logAudit(
            appId = "dynamic_dex",
            appName = className,
            actionType = "DEX_LOADED",
            details = if (result.isSuccess) "Dynamic Dex loaded in ${result.loadDurationMs}ms -> ${result.executionResult}"
            else "Dex load failed: ${result.errorMessage}",
            status = if (result.isSuccess) "SUCCESS" else "DENIED"
        )

        return result
    }

    fun generateSampleDynamicDex(moduleId: String, moduleName: String): File {
        return dynamicDexLoader.createSampleDynamicModule(moduleId, moduleName)
    }

    // Installed apps from device
    fun getDeviceInstalledApps(existingVaultPackageNames: Set<String>): List<InstalledAppInfo> {
        return appLauncherManager.getInstalledLaunchableApps(existingVaultPackageNames)
    }

    fun convertToVaultEntity(appInfo: InstalledAppInfo): VaultAppEntity {
        return appLauncherManager.convertToVaultEntity(appInfo)
    }

    suspend fun logAudit(
        appId: String,
        appName: String,
        actionType: String,
        details: String,
        status: String
    ) {
        vaultDao.insertAuditLog(
            AuditLogEntity(
                appId = appId,
                appName = appName,
                actionType = actionType,
                details = details,
                status = status
            )
        )
    }

    suspend fun clearAuditLogs() {
        vaultDao.clearAuditLogs()
    }
}
