package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_apps ORDER BY lastLaunchedTimestamp DESC")
    fun getAllVaultApps(): Flow<List<VaultAppEntity>>

    @Query("SELECT * FROM vault_apps WHERE appId = :appId")
    suspend fun getVaultAppById(appId: String): VaultAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateApp(app: VaultAppEntity)

    @Query("DELETE FROM vault_apps WHERE appId = :appId")
    suspend fun deleteAppById(appId: String)

    @Query("UPDATE vault_apps SET storageSizeBytes = :bytes WHERE appId = :appId")
    suspend fun updateStorageSize(appId: String, bytes: Long)

    @Query("UPDATE vault_apps SET lastLaunchedTimestamp = :timestamp WHERE appId = :appId")
    suspend fun updateLastLaunched(appId: String, timestamp: Long)

    @Query("UPDATE vault_apps SET isLocked = :isLocked WHERE appId = :appId")
    suspend fun updateLockStatus(appId: String, isLocked: Boolean)

    // Audit logs
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Query("DELETE FROM audit_logs")
    suspend fun clearAuditLogs()
}

@Database(entities = [VaultAppEntity::class, AuditLogEntity::class], version = 1, exportSchema = false)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun vaultDao(): VaultDao
}
