package com.example.loader

/**
 * Public contract interface for dynamic plugins or feature modules
 * loaded into memory via DexClassLoader.
 */
interface VaultPluginInterface {
    fun getPluginId(): String
    fun getPluginName(): String
    fun getVersion(): String
    fun execute(input: String): String
    fun getStatusSummary(): String
}

/**
 * Result model for dynamic DEX class loading and reflection calls.
 */
data class DexLoadResult(
    val isSuccess: Boolean,
    val className: String,
    val loadedMethods: List<String>,
    val executionResult: String,
    val errorMessage: String? = null,
    val dexPath: String,
    val optimizedDexDir: String,
    val loadDurationMs: Long
)
