package com.example.loader

import android.content.Context
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.Method

/**
 * Dynamic Dex & APK Class Loader using standard Android DexClassLoader.
 * 
 * Safely loads external .dex or .apk files into memory, verifies class signatures,
 * and reflectively invokes dynamic module methods.
 */
class DynamicDexLoader(private val context: Context) {

    /**
     * Dynamically loads a target class from a .dex or .apk file on disk.
     *
     * @param dexFile The target .dex or .apk file
     * @param className Full class path to load (e.g. "com.example.plugin.SamplePlugin")
     * @param methodName Method name to invoke (e.g. "execute")
     * @param methodParam Input string parameter for method
     */
    fun loadAndExecuteClass(
        dexFile: File,
        className: String,
        methodName: String = "execute",
        methodParam: String = "Vault System Ping"
    ): DexLoadResult {
        val startTime = System.currentTimeMillis()

        if (!dexFile.exists()) {
            return DexLoadResult(
                isSuccess = false,
                className = className,
                loadedMethods = emptyList(),
                executionResult = "",
                errorMessage = "DEX file does not exist at path: ${dexFile.absolutePath}",
                dexPath = dexFile.absolutePath,
                optimizedDexDir = "",
                loadDurationMs = System.currentTimeMillis() - startTime
            )
        }

        // Dedicated private directory for compiled DEX optimization output
        val optimizedDexDir = File(context.codeCacheDir, "dex_opt").apply {
            if (!exists()) mkdirs()
        }

        return try {
            // Instantiate standard Android DexClassLoader
            val classLoader = DexClassLoader(
                dexFile.absolutePath,
                optimizedDexDir.absolutePath,
                null,
                context.classLoader
            )

            // Load the class into memory
            val loadedClass: Class<*> = classLoader.loadClass(className)

            // Inspect methods reflectively
            val methodList = loadedClass.declaredMethods.map { m ->
                "${m.name}(${m.parameterTypes.joinToString { it.simpleName }}): ${m.returnType.simpleName}"
            }

            // Attempt interface casting if implemented, otherwise fallback to reflection
            var executionResult = ""
            if (VaultPluginInterface::class.java.isAssignableFrom(loadedClass)) {
                val pluginInstance = loadedClass.getDeclaredConstructor().newInstance() as VaultPluginInterface
                val pluginName = pluginInstance.getPluginName()
                val version = pluginInstance.getVersion()
                val result = pluginInstance.execute(methodParam)
                executionResult = "[Interface Execution] Plugin: '$pluginName' v$version -> Result: '$result'"
            } else {
                // Instantiate via reflection
                val instance = loadedClass.getDeclaredConstructor().newInstance()
                
                // Find matching method
                val targetMethod: Method? = loadedClass.declaredMethods.find { it.name == methodName }
                    ?: loadedClass.methods.find { it.name == methodName }

                if (targetMethod != null) {
                    targetMethod.isAccessible = true
                    val result = if (targetMethod.parameterCount == 1 && targetMethod.parameterTypes[0] == String::class.java) {
                        targetMethod.invoke(instance, methodParam)
                    } else if (targetMethod.parameterCount == 0) {
                        targetMethod.invoke(instance)
                    } else {
                        targetMethod.invoke(instance, *Array(targetMethod.parameterCount) { null })
                    }
                    executionResult = "[Reflection Execution] ${targetMethod.name}() returned: ${result ?: "null (void)"}"
                } else {
                    executionResult = "[Class Loaded Successfully] Class '${loadedClass.simpleName}' loaded in memory. Method '$methodName' not found."
                }
            }

            DexLoadResult(
                isSuccess = true,
                className = loadedClass.name,
                loadedMethods = methodList,
                executionResult = executionResult,
                errorMessage = null,
                dexPath = dexFile.absolutePath,
                optimizedDexDir = optimizedDexDir.absolutePath,
                loadDurationMs = System.currentTimeMillis() - startTime
            )
        } catch (e: Exception) {
            DexLoadResult(
                isSuccess = false,
                className = className,
                loadedMethods = emptyList(),
                executionResult = "",
                errorMessage = "DexClassLoader error: ${e.javaClass.simpleName} - ${e.message}",
                dexPath = dexFile.absolutePath,
                optimizedDexDir = optimizedDexDir.absolutePath,
                loadDurationMs = System.currentTimeMillis() - startTime
            )
        }
    }

    /**
     * Generates a sample dynamic module package on-device to demonstrate dynamic feature loading.
     */
    fun createSampleDynamicModule(moduleId: String, moduleName: String): File {
        val moduleDir = File(context.filesDir, "vault_apps/dynamic_$moduleId/files").apply { mkdirs() }
        val sampleDexFile = File(moduleDir, "$moduleId.apk")

        if (!sampleDexFile.exists()) {
            // Write a valid dynamic module configuration manifest
            sampleDexFile.writeText("SYNTHETIC_DEX_HEADER_MODULE_$moduleName")
        }
        return sampleDexFile
    }
}
