package com.example.loader

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.content.res.Resources
import java.io.File

/**
 * Enterprise ContextWrapper demonstrating Context & Storage isolation in Android.
 *
 * Wraps a base Context to reroute file paths, shared preferences, databases, and
 * resources into a dedicated private isolated sandbox directory (`/data/data/com.app/files/vault_apps/{appId}/`).
 */
class VaultContextWrapper(
    baseContext: Context,
    val appId: String,
    val isolatedPackageName: String
) : ContextWrapper(baseContext) {

    private val isolatedDir: File by lazy {
        File(baseContext.filesDir, "vault_apps/$appId").apply { mkdirs() }
    }

    override fun getFilesDir(): File {
        return File(isolatedDir, "files").apply { mkdirs() }
    }

    override fun getCacheDir(): File {
        return File(isolatedDir, "cache").apply { mkdirs() }
    }

    override fun getDatabasePath(name: String): File {
        val dbDir = File(isolatedDir, "databases").apply { mkdirs() }
        return File(dbDir, name)
    }

    override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
        // Shared preferences redirect to isolated name prefix
        val isolatedPrefName = "vault_${appId}_$name"
        return super.getSharedPreferences(isolatedPrefName, mode)
    }

    override fun getPackageName(): String {
        return isolatedPackageName
    }

    /**
     * Overrides createPackageContext to inspect or create context for external packages safely.
     */
    override fun createPackageContext(packageName: String, flags: Int): Context {
        return try {
            val originalContext = super.createPackageContext(packageName, flags)
            VaultContextWrapper(originalContext, appId, packageName)
        } catch (e: Exception) {
            this
        }
    }

    /**
     * Safely retrieves target package resources or fallback to base resources.
     */
    fun getPackageResources(targetPackageName: String): Resources? {
        return try {
            val pm = packageManager
            pm.getResourcesForApplication(targetPackageName)
        } catch (e: Exception) {
            resources
        }
    }
}
