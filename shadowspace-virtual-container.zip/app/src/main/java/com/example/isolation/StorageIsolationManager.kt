package com.example.isolation

import android.content.Context
import java.io.File

data class VaultStorageInfo(
    val appId: String,
    val rootPath: String,
    val filesDirExist: Boolean,
    val databasesDirExist: Boolean,
    val prefsDirExist: Boolean,
    val cacheDirExist: Boolean,
    val totalSizeBytes: Long,
    val totalFilesCount: Int
)

class StorageIsolationManager(private val context: Context) {

    private val vaultBaseDir: File
        get() {
            val dir = File(context.filesDir, "vault_apps")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    /**
     * Initializes a private isolated storage directory structure for a target app.
     * Android Context.filesDir + "/vault_apps/{appId}/"
     */
    fun createIsolatedStorage(appId: String): VaultStorageInfo {
        val appDirectory = File(vaultBaseDir, sanitizeAppId(appId))
        val filesDir = File(appDirectory, "files")
        val databasesDir = File(appDirectory, "databases")
        val prefsDir = File(appDirectory, "shared_prefs")
        val cacheDir = File(appDirectory, "cache")
        val dexOptDir = File(appDirectory, "dex_opt")

        filesDir.mkdirs()
        databasesDir.mkdirs()
        prefsDir.mkdirs()
        cacheDir.mkdirs()
        dexOptDir.mkdirs()

        // Create initial isolation manifest file
        val manifest = File(appDirectory, "isolation_manifest.json")
        if (!manifest.exists()) {
            manifest.writeText(
                """
                {
                    "appId": "$appId",
                    "createdTimestamp": ${System.currentTimeMillis()},
                    "sandboxIsolation": "STRICT_PRIVATE_DIRECTORY",
                    "path": "${appDirectory.absolutePath}"
                }
                """.trimIndent()
            )
        }

        return getStorageInfo(appId)
    }

    /**
     * Calculates storage footprint recursively.
     */
    fun getStorageInfo(appId: String): VaultStorageInfo {
        val appDirectory = File(vaultBaseDir, sanitizeAppId(appId))
        if (!appDirectory.exists()) {
            return VaultStorageInfo(
                appId = appId,
                rootPath = appDirectory.absolutePath,
                filesDirExist = false,
                databasesDirExist = false,
                prefsDirExist = false,
                cacheDirExist = false,
                totalSizeBytes = 0L,
                totalFilesCount = 0
            )
        }

        val totalSizeBytes = calculateDirectorySize(appDirectory)
        val fileCount = countFiles(appDirectory)

        return VaultStorageInfo(
            appId = appId,
            rootPath = appDirectory.absolutePath,
            filesDirExist = File(appDirectory, "files").exists(),
            databasesDirExist = File(appDirectory, "databases").exists(),
            prefsDirExist = File(appDirectory, "shared_prefs").exists(),
            cacheDirExist = File(appDirectory, "cache").exists(),
            totalSizeBytes = totalSizeBytes,
            totalFilesCount = fileCount
        )
    }

    /**
     * Executes test I/O inside the isolated sandbox to demonstrate private file creation.
     */
    fun writeTestFileInSandbox(appId: String, fileName: String, content: String): File {
        val storageInfo = createIsolatedStorage(appId)
        val targetFile = File(storageInfo.rootPath + "/files", fileName)
        targetFile.writeText(content)
        return targetFile
    }

    /**
     * Reads all test files from the isolated sandbox.
     */
    fun readFilesFromSandbox(appId: String): List<Pair<String, String>> {
        val appDirectory = File(vaultBaseDir, sanitizeAppId(appId))
        val filesDir = File(appDirectory, "files")
        if (!filesDir.exists()) return emptyList()

        return filesDir.listFiles()?.map { file ->
            file.name to runCatching { file.readText() }.getOrDefault("<binary or unreadable>")
        } ?: emptyList()
    }

    /**
     * Clears all isolated data for the specified app (Wipe Sandbox).
     */
    fun clearIsolatedData(appId: String): Boolean {
        val appDirectory = File(vaultBaseDir, sanitizeAppId(appId))
        if (appDirectory.exists()) {
            val result = appDirectory.deleteRecursively()
            createIsolatedStorage(appId) // Re-initialize clean structure
            return result
        }
        return false
    }

    private fun sanitizeAppId(appId: String): String {
        return appId.replace("[^a-zA-Z0-9._-]".toRegex(), "_")
    }

    private fun calculateDirectorySize(dir: File): Long {
        if (!dir.exists()) return 0L
        if (dir.isFile) return dir.length()
        var size = 0L
        dir.listFiles()?.forEach { child ->
            size += calculateDirectorySize(child)
        }
        return size
    }

    private fun countFiles(dir: File): Int {
        if (!dir.exists()) return 0
        if (dir.isFile) return 1
        var count = 0
        dir.listFiles()?.forEach { child ->
            count += countFiles(child)
        }
        return count
    }
}
