package com.example.security

import android.content.Context
import android.content.SharedPreferences

class VaultSecurityManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_vault_security_prefs", Context.MODE_PRIVATE)

    var isVaultUnlocked: Boolean = false
        private set

    val pinCode: String
        get() = prefs.getString(KEY_PIN_CODE, "1234") ?: "1234"

    val isPinSet: Boolean
        get() = prefs.contains(KEY_PIN_CODE)

    fun verifyPin(inputPin: String): Boolean {
        val matches = inputPin == pinCode
        if (matches) {
            isVaultUnlocked = true
        }
        return matches
    }

    fun lockVault() {
        isVaultUnlocked = false
    }

    fun updatePinCode(oldPin: String, newPin: String): Boolean {
        if (verifyPin(oldPin)) {
            prefs.edit().putString(KEY_PIN_CODE, newPin).apply()
            isVaultUnlocked = true
            return true
        }
        return false
    }

    fun setInitialPin(newPin: String) {
        prefs.edit().putString(KEY_PIN_CODE, newPin).apply()
        isVaultUnlocked = true
    }

    companion object {
        private const val KEY_PIN_CODE = "vault_pin_code_hash"
    }
}
