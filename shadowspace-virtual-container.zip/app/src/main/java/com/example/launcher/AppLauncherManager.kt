package com.example.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.example.data.VaultAppEntity

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isSystemApp: Boolean,
    val icon: ImageBitmap?,
    val isAlreadyInVault: Boolean = false
)

class AppLauncherManager(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    /**
     * Queries all launchable applications installed on the device using standard Android PackageManager APIs.
     */
    fun getInstalledLaunchableApps(existingVaultPackageNames: Set<String>): List<InstalledAppInfo> {
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfoList = packageManager.queryIntentActivities(
            launcherIntent,
            PackageManager.MATCH_ALL
        )

        val appList = mutableListOf<InstalledAppInfo>()
        val seenPackages = mutableSetOf<String>()

        for (resolveInfo in resolveInfoList) {
            val pkgName = resolveInfo.activityInfo.packageName
            
            // Skip self and duplicate entries
            if (pkgName == context.packageName || seenPackages.contains(pkgName)) {
                continue
            }
            seenPackages.add(pkgName)

            try {
                val appInfo = packageManager.getApplicationInfo(pkgName, 0)
                val label = packageManager.getApplicationLabel(appInfo).toString()
                
                val pkgInfo = runCatching {
                    packageManager.getPackageInfo(pkgName, 0)
                }.getOrNull()

                val versionName = pkgInfo?.versionName ?: "1.0"
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                val iconDrawable = runCatching {
                    packageManager.getApplicationIcon(appInfo)
                }.getOrNull()

                val iconBitmap = iconDrawable?.toBitmap(width = 96, height = 96)?.asImageBitmap()

                appList.add(
                    InstalledAppInfo(
                        packageName = pkgName,
                        appName = label,
                        versionName = versionName,
                        isSystemApp = isSystem,
                        icon = iconBitmap,
                        isAlreadyInVault = existingVaultPackageNames.contains(pkgName)
                    )
                )
            } catch (e: Exception) {
                // Continue if package info cannot be retrieved
            }
        }

        return appList.sortedBy { it.appName.lowercase() }
    }

    /**
     * Converts an installed application info into a VaultAppEntity for persistence.
     */
    fun convertToVaultEntity(appInfo: InstalledAppInfo): VaultAppEntity {
        return VaultAppEntity(
            appId = appInfo.packageName,
            appName = appInfo.appName,
            packageName = appInfo.packageName,
            versionName = appInfo.versionName,
            isIsolated = true,
            isDynamicPlugin = false,
            isSystemApp = appInfo.isSystemApp,
            isLocked = false,
            storageSizeBytes = 0L,
            lastLaunchedTimestamp = System.currentTimeMillis(),
            category = if (appInfo.isSystemApp) "System Tool" else "Installed App",
            description = "Protected container app instance for ${appInfo.appName}"
        )
    }

    /**
     * Launches the target application safely using standard Intent APIs.
     */
    fun launchAppPackage(packageName: String): Boolean {
        return try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Retrieves application icon drawable by package name.
     */
    fun getAppIconDrawable(packageName: String): Drawable? {
        return try {
            packageManager.getApplicationIcon(packageName)
        } catch (e: Exception) {
            null
        }
    }
}
