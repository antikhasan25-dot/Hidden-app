package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppDetailDialog
import com.example.ui.components.ArchitectureBannerCard
import com.example.ui.components.AuditLogItem
import com.example.ui.components.DynamicPluginCard
import com.example.ui.components.LockPinDialog
import com.example.ui.components.VaultAppCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultHomeScreen(
    viewModel: VaultViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val vaultApps by viewModel.vaultApps.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val deviceInstalledApps by viewModel.deviceInstalledApps.collectAsStateWithLifecycle()
    val isLoadingInstalledApps by viewModel.isLoadingInstalledApps.collectAsStateWithLifecycle()
    val selectedAppForDetail by viewModel.selectedAppForDetail.collectAsStateWithLifecycle()
    val currentAppStorageInfo by viewModel.currentAppStorageInfo.collectAsStateWithLifecycle()
    val sandboxFiles by viewModel.sandboxFiles.collectAsStateWithLifecycle()
    val dexLoadResult by viewModel.dexLoadResult.collectAsStateWithLifecycle()
    val isExecutingDex by viewModel.isExecutingDex.collectAsStateWithLifecycle()
    val showPinDialog by viewModel.showPinDialog.collectAsStateWithLifecycle()
    val pinErrorMessage by viewModel.pinErrorMessage.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Vault Logo",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "App Vault",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (viewModel.securityManager.isVaultUnlocked) "Session: Unlocked" else "Session: Protected",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (viewModel.securityManager.isVaultUnlocked) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (viewModel.securityManager.isVaultUnlocked) {
                                viewModel.securityManager.lockVault()
                            } else {
                                viewModel.verifyPinCode("1234") // Quick lock toggle
                            }
                        },
                        modifier = Modifier.testTag("lock_session_toggle")
                    ) {
                        Icon(
                            imageVector = if (viewModel.securityManager.isVaultUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                            contentDescription = "Session Lock",
                            tint = if (viewModel.securityManager.isVaultUnlocked) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                        )
                    }

                    IconButton(
                        onClick = { viewModel.loadDeviceInstalledApps() },
                        modifier = Modifier.testTag("refresh_button")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = { viewModel.setSelectedTab(2) }, // Navigate to device app inspector
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_app")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add App to Vault")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Navigation Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { viewModel.setSelectedTab(0) },
                    text = { Text("App Vault", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Shield, contentDescription = null) },
                    modifier = Modifier.testTag("tab_vault")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { viewModel.setSelectedTab(1) },
                    text = { Text("Dynamic Dex", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Code, contentDescription = null) },
                    modifier = Modifier.testTag("tab_dex")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { viewModel.setSelectedTab(2) },
                    text = { Text("App Inspector", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Android, contentDescription = null) },
                    modifier = Modifier.testTag("tab_inspector")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { viewModel.setSelectedTab(3) },
                    text = { Text("Audit Logs", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Security, contentDescription = null) },
                    modifier = Modifier.testTag("tab_audit")
                )
            }

            // Tab Content Body
            when (selectedTab) {
                0 -> VaultAppsTabContent(
                    vaultApps = vaultApps,
                    searchQuery = searchQuery,
                    selectedCategory = selectedCategory,
                    onSearchQueryChange = viewModel::setSearchQuery,
                    onCategorySelect = viewModel::setSelectedCategory,
                    onLaunchApp = viewModel::launchVaultApp,
                    onToggleLock = viewModel::toggleAppLock,
                    onOpenDetail = viewModel::openAppDetailDialog
                )
                1 -> DynamicDexTabContent(
                    isExecuting = isExecutingDex,
                    dexResult = dexLoadResult,
                    onExecuteDex = viewModel::executeSampleDynamicDex
                )
                2 -> AppInspectorTabContent(
                    isLoading = isLoadingInstalledApps,
                    installedApps = deviceInstalledApps,
                    onAddAppToVault = viewModel::addInstalledAppToVault,
                    onRefresh = viewModel::loadDeviceInstalledApps
                )
                3 -> AuditLogsTabContent(
                    auditLogs = auditLogs,
                    onClearAuditLogs = viewModel::clearAuditLogs
                )
            }
        }
    }

    // PIN Authentication Dialog
    if (showPinDialog) {
        LockPinDialog(
            errorMessage = pinErrorMessage,
            onVerifyPin = viewModel::verifyPinCode,
            onDismiss = viewModel::dismissPinDialog
        )
    }

    // App Sandbox Detail Dialog
    if (selectedAppForDetail != null) {
        AppDetailDialog(
            app = selectedAppForDetail!!,
            storageInfo = currentAppStorageInfo,
            sandboxFiles = sandboxFiles,
            onClearData = { viewModel.clearAppSandboxData(selectedAppForDetail!!) },
            onCreateTestFile = { name, content ->
                viewModel.createTestSandboxFile(selectedAppForDetail!!.appId, name, content)
            },
            onRemoveFromVault = { viewModel.removeVaultApp(selectedAppForDetail!!) },
            onDismiss = viewModel::closeAppDetailDialog
        )
    }
}

@Composable
private fun VaultAppsTabContent(
    vaultApps: List<com.example.data.VaultAppEntity>,
    searchQuery: String,
    selectedCategory: String,
    onSearchQueryChange: (String) -> Unit,
    onCategorySelect: (String) -> Unit,
    onLaunchApp: (com.example.data.VaultAppEntity) -> Unit,
    onToggleLock: (com.example.data.VaultAppEntity) -> Unit,
    onOpenDetail: (com.example.data.VaultAppEntity) -> Unit
) {
    val categories = listOf("All", "Enterprise", "Dynamic Plugin", "System Tool")

    val filteredApps = vaultApps.filter { app ->
        val matchesCategory = selectedCategory == "All" || app.category.equals(selectedCategory, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
                app.appName.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        ArchitectureBannerCard()

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search vault apps or package name...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("vault_search_input"),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Chips
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { onCategorySelect(cat) },
                    label = { Text(cat, fontSize = 12.sp) },
                    modifier = Modifier.testTag("chip_$cat")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No apps found in vault",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Use the App Inspector tab to add apps from device.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 280.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredApps, key = { it.appId }) { app ->
                    VaultAppCard(
                        app = app,
                        onLaunchClick = { onLaunchApp(app) },
                        onToggleLock = { onToggleLock(app) },
                        onDetailClick = { onOpenDetail(app) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DynamicDexTabContent(
    isExecuting: Boolean,
    dexResult: com.example.loader.DexLoadResult?,
    onExecuteDex: (className: String, methodName: String, param: String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        DynamicPluginCard(
            isExecuting = isExecuting,
            dexResult = dexResult,
            onExecuteDexClick = onExecuteDex
        )
    }
}

@Composable
private fun AppInspectorTabContent(
    isLoading: Boolean,
    installedApps: List<com.example.launcher.InstalledAppInfo>,
    onAddAppToVault: (com.example.launcher.InstalledAppInfo) -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Device Installed Apps",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Scanned via PackageManager API",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(onClick = onRefresh) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Scan Apps")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Scanning device installed applications...")
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(installedApps, key = { it.packageName }) { app ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Android,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.appName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = app.packageName,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (app.isAlreadyInVault) {
                                Text(
                                    text = "In Vault",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF10B981)
                                )
                            } else {
                                Button(
                                    onClick = { onAddAppToVault(app) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add to Vault", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditLogsTabContent(
    auditLogs: List<com.example.data.AuditLogEntity>,
    onClearAuditLogs: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Isolation Audit Trail",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${auditLogs.size} recorded isolation & launch events",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(onClick = onClearAuditLogs) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear Logs",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (auditLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No isolation audit logs recorded.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(auditLogs, key = { it.id }) { log ->
                    AuditLogItem(log = log)
                }
            }
        }
    }
}
