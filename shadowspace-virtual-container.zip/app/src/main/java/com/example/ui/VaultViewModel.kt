package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.AuditLogEntity
import com.example.data.VaultAppEntity
import com.example.data.VaultDatabase
import com.example.data.VaultRepository
import com.example.isolation.StorageIsolationManager
import com.example.isolation.VaultStorageInfo
import com.example.launcher.AppLauncherManager
import com.example.launcher.InstalledAppInfo
import com.example.loader.DexLoadResult
import com.example.loader.DynamicDexLoader
import com.example.security.VaultSecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class VaultViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        VaultDatabase::class.java,
        "app_vault_db"
    ).fallbackToDestructiveMigration().build()

    private val storageIsolationManager = StorageIsolationManager(application)
    private val dynamicDexLoader = DynamicDexLoader(application)
    private val appLauncherManager = AppLauncherManager(application)
    val securityManager = VaultSecurityManager(application)

    val repository = VaultRepository(
        vaultDao = db.vaultDao(),
        storageIsolationManager = storageIsolationManager,
        dynamicDexLoader = dynamicDexLoader,
        appLauncherManager = appLauncherManager
    )

    val vaultApps: StateFlow<List<VaultAppEntity>> = repository.allVaultApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI State
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _deviceInstalledApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val deviceInstalledApps: StateFlow<List<InstalledAppInfo>> = _deviceInstalledApps.asStateFlow()

    private val _isLoadingInstalledApps = MutableStateFlow(false)
    val isLoadingInstalledApps: StateFlow<Boolean> = _isLoadingInstalledApps.asStateFlow()

    private val _selectedAppForDetail = MutableStateFlow<VaultAppEntity?>(null)
    val selectedAppForDetail: StateFlow<VaultAppEntity?> = _selectedAppForDetail.asStateFlow()

    private val _currentAppStorageInfo = MutableStateFlow<VaultStorageInfo?>(null)
    val currentAppStorageInfo: StateFlow<VaultStorageInfo?> = _currentAppStorageInfo.asStateFlow()

    private val _sandboxFiles = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val sandboxFiles: StateFlow<List<Pair<String, String>>> = _sandboxFiles.asStateFlow()

    // Dynamic Dex Test State
    private val _dexLoadResult = MutableStateFlow<DexLoadResult?>(null)
    val dexLoadResult: StateFlow<DexLoadResult?> = _dexLoadResult.asStateFlow()

    private val _isExecutingDex = MutableStateFlow(false)
    val isExecutingDex: StateFlow<Boolean> = _isExecutingDex.asStateFlow()

    // Lock screen / Security state
    private val _showPinDialog = MutableStateFlow(false)
    val showPinDialog: StateFlow<Boolean> = _showPinDialog.asStateFlow()

    private val _pinErrorMessage = MutableStateFlow<String?>(null)
    val pinErrorMessage: StateFlow<String?> = _pinErrorMessage.asStateFlow()

    private val _pendingLockedAction = MutableStateFlow<(() -> Unit)?>(null)

    init {
        // Populate default enterprise vault apps if empty
        viewModelScope.launch(Dispatchers.IO) {
            val count = vaultApps.value.size
            if (count == 0) {
                seedInitialVaultApps()
            }
        }
    }

    private suspend fun seedInitialVaultApps() {
        val defaultApps = listOf(
            VaultAppEntity(
                appId = "com.enterprise.crm.vault",
                appName = "Enterprise CRM Vault",
                packageName = "com.enterprise.crm.vault",
                versionName = "2.4.0",
                isIsolated = true,
                isDynamicPlugin = false,
                isSystemApp = false,
                isLocked = true,
                storageSizeBytes = 1240000L,
                category = "Enterprise",
                description = "Isolated customer management database & secure notes"
            ),
            VaultAppEntity(
                appId = "com.vault.dynamic.analytics",
                appName = "Analytics Plugin (Dynamic Dex)",
                packageName = "com.vault.dynamic.analytics",
                versionName = "1.0.8",
                isIsolated = true,
                isDynamicPlugin = true,
                isSystemApp = false,
                isLocked = false,
                storageSizeBytes = 450000L,
                category = "Dynamic Plugin",
                description = "Dynamically loaded Dex feature module running via DexClassLoader"
            ),
            VaultAppEntity(
                appId = "com.android.settings",
                appName = "System Settings Sandbox",
                packageName = "com.android.settings",
                versionName = "OS Native",
                isIsolated = true,
                isDynamicPlugin = false,
                isSystemApp = true,
                isLocked = false,
                storageSizeBytes = 890000L,
                category = "System Tool",
                description = "Sandboxed wrapper for system configuration settings"
            )
        )

        for (app in defaultApps) {
            repository.addAppToVault(app)
        }
    }

    fun setSelectedTab(index: Int) {
        _selectedTab.value = index
        if (index == 2 && _deviceInstalledApps.value.isEmpty()) {
            loadDeviceInstalledApps()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun loadDeviceInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingInstalledApps.value = true
            val vaultPkgNames = vaultApps.value.map { it.packageName }.toSet()
            val apps = repository.getDeviceInstalledApps(vaultPkgNames)
            _deviceInstalledApps.value = apps
            _isLoadingInstalledApps.value = false
        }
    }

    fun addInstalledAppToVault(appInfo: InstalledAppInfo) {
        viewModelScope.launch(Dispatchers.IO) {
            val entity = repository.convertToVaultEntity(appInfo)
            repository.addAppToVault(entity)
            loadDeviceInstalledApps() // Refresh list
        }
    }

    fun launchVaultApp(app: VaultAppEntity) {
        if (app.isLocked && !securityManager.isVaultUnlocked) {
            // Prompt for PIN first
            _pendingLockedAction.value = { executeLaunchVaultApp(app) }
            _showPinDialog.value = true
            return
        }
        executeLaunchVaultApp(app)
    }

    private fun executeLaunchVaultApp(app: VaultAppEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.launchVaultApp(app)
        }
    }

    fun toggleAppLock(app: VaultAppEntity) {
        if (!securityManager.isVaultUnlocked) {
            _pendingLockedAction.value = { executeToggleAppLock(app) }
            _showPinDialog.value = true
            return
        }
        executeToggleAppLock(app)
    }

    private fun executeToggleAppLock(app: VaultAppEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleLockStatus(app.appId, app.appName, app.isLocked)
        }
    }

    fun openAppDetailDialog(app: VaultAppEntity) {
        _selectedAppForDetail.value = app
        viewModelScope.launch(Dispatchers.IO) {
            _currentAppStorageInfo.value = repository.getStorageInfo(app.appId)
            _sandboxFiles.value = repository.readSandboxFiles(app.appId)
        }
    }

    fun closeAppDetailDialog() {
        _selectedAppForDetail.value = null
        _currentAppStorageInfo.value = null
        _sandboxFiles.value = emptyList()
    }

    fun clearAppSandboxData(app: VaultAppEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val newInfo = repository.clearSandboxStorage(app.appId, app.appName)
            _currentAppStorageInfo.value = newInfo
            _sandboxFiles.value = repository.readSandboxFiles(app.appId)
        }
    }

    fun createTestSandboxFile(appId: String, fileName: String, content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.writeSandboxTestFile(appId, fileName, content)
            val app = _selectedAppForDetail.value
            if (app != null) {
                _currentAppStorageInfo.value = repository.getStorageInfo(app.appId)
                _sandboxFiles.value = repository.readSandboxFiles(app.appId)
            }
            repository.logAudit(
                appId = appId,
                appName = appId,
                actionType = "ISOLATED_IO",
                details = "Wrote private sandbox test file '$fileName' (${content.length} chars)",
                status = "SUCCESS"
            )
        }
    }

    fun removeVaultApp(app: VaultAppEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeAppFromVault(app.appId, app.appName)
            if (_selectedAppForDetail.value?.appId == app.appId) {
                closeAppDetailDialog()
            }
        }
    }

    fun executeSampleDynamicDex(className: String, methodName: String, param: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _isExecutingDex.value = true
            val sampleModuleFile = repository.generateSampleDynamicDex("sample_plugin_01", "Vault Security Module")
            
            val result = repository.loadDynamicDexModule(
                dexFile = sampleModuleFile,
                className = className,
                methodName = methodName,
                param = param
            )
            
            _dexLoadResult.value = result
            _isExecutingDex.value = false
        }
    }

    fun verifyPinCode(pin: String) {
        if (securityManager.verifyPin(pin)) {
            _showPinDialog.value = false
            _pinErrorMessage.value = null
            _pendingLockedAction.value?.invoke()
            _pendingLockedAction.value = null
        } else {
            _pinErrorMessage.value = "Incorrect PIN code. Try default '1234'."
        }
    }

    fun dismissPinDialog() {
        _showPinDialog.value = false
        _pinErrorMessage.value = null
        _pendingLockedAction.value = null
    }

    fun updatePinCode(oldPin: String, newPin: String): Boolean {
        return securityManager.updatePinCode(oldPin, newPin)
    }

    fun clearAuditLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAuditLogs()
        }
    }
}
