package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VaultSlate900 = Color(0xFF0F172A)
val VaultSlate800 = Color(0xFF1E293B)
val VaultSlate700 = Color(0xFF334155)

val CyanPrimary = Color(0xFF06B6D4)
val CyanPrimaryLight = Color(0xFF67E8F9)
val CyanPrimaryDark = Color(0xFF0891B2)

val EmeraldSecurity = Color(0xFF10B981)
val EmeraldSecurityContainer = Color(0xFF064E3B)

val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)

val VaultSurfaceDark = Color(0xFF0F172A)
val VaultCardDark = Color(0xFF1E293B)
val VaultBorderDark = Color(0xFF334155)

val VaultSurfaceLight = Color(0xFFF8FAFC)
val VaultCardLight = Color(0xFFFFFFFF)
val VaultBorderLight = Color(0xFFE2E8F0)

